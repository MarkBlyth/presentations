void nlogcensor(int*,double*,double*,double*,int*,double*);
